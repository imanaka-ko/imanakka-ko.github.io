// Rename this file to firebase-config.js and fill with your project's values.
// You can find these in Firebase console → Project settings → General → Your apps (Web).
export const firebaseConfig = {
  apiKey: "AIzaSyA9o-NOGNp6QgaAKkGdmWbsWiq_4Tds5A4",
  authDomain: "shukatsu-spi.firebaseapp.com",
  projectId: "shukatsu-spi",
  storageBucket: "shukatsu-spi.firebasestorage.app",
  messagingSenderId: "148839722141",
  appId: "1:148839722141:web:bf2753980bb277d875b874",
  measurementId: "G-5MWYQ328DM"
};
